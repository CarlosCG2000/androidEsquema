package es.upsa.mimo.recyclerview

data class Contacto(val id: Long,
                    val nombre: String,
                    val email: String,
                    val telefono: String,
                    val direccion: String)
{}