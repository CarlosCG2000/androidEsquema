package es.upsa.mimo.recyclerview

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.random.Random

class ContactoRepository: Repository
{
    private val data : MutableMap<Long, Contacto> = mutableMapOf( Pair(1L, Contacto(1L, "Carlos", "carlos@gmail.com",       "612-345-678", "Compañía 5")),
                                                                  Pair(2L, Contacto(2L, "Marta", "marta@gmail.com",         "623-456-789", "Rúa 23")),
                                                                  Pair(3L, Contacto(3L, "Maria", "maria@gmail.com",         "634-567-890", "Alemania 44")),
                                                                  Pair(4L, Contacto(4L, "Luis", "luis@gmail.com",           "645-678-901", "Arcipreste de Hita 12")),
                                                                  Pair(5L, Contacto(5L, "Teresa", "teresa@gmail.com",       "656-789-012", "Calle Ancha 3")),
                                                                  Pair(6L, Contacto(6L, "Marcos", "marcos@gmail.com",       "667-890-123", "Libreros 21")),
                                                                  Pair(7L, Contacto(7L, "Lucía", "lucia@gmail.com",         "678-901-234", "Toro 76")),
                                                                  Pair(8L, Contacto(8L, "Alejandro", "alejandro@gmail.com", "689-012-345", "Zamora 62")),
                                                                  Pair(9L, Contacto(9L, "Raúl", "mraul@gmail.com",          "690-123-456", "Torres Villarroel 14")),
                                                                  Pair(10L, Contacto(10L, "Ana", "ana@gmail.com",           "601-234-567", "Villamayor 10")),
                                                                  Pair(11L, Contacto(11L, "Mónica", "monica@gmail.com",     "660-987-654", "Pso. Estación 47")),
                                                                  Pair(12L, Contacto(12L, "Pablo", "pablo@gmail.com",       "669-876-543", "Corredera 34")),
                                                                  Pair(13L, Contacto(13L, "Oscar", "oscar@gmail.com",       "668-765-432", "Lancia 60"))
                                                                )

    private val _contactos: MutableStateFlow< List<Contacto> > = MutableStateFlow( data.values.toList() )
    private val contactos: StateFlow< List<Contacto> > = _contactos.asStateFlow()

    override fun findAll(): List<Contacto>
    {
        return data.values.toList()

    }

    override fun findAllAsFlow(): Flow< List<Contacto> > = contactos


    override fun findById(id: Long): Contacto?
    {
        return data.get(id)
    }


    override fun insertContacto(contacto: Contacto): Contacto
    {
        val newContacto = contacto.copy(id = createId())
        data.put(newContacto.id, newContacto)
        syncContactos()
        return newContacto
    }

    override fun updateContacto(contacto: Contacto): Contacto?
    {
        if ( data.replace(contacto.id, contacto) != null )
        {
            syncContactos()
            return contacto
        }
        return null
    }


    private fun syncContactos()
    {
        _contactos.value = data.values.toList()
    }

    private fun createId(): Long
    {
        var id = 0L;
        val random = Random(1_000_000_000L)
        do
        {
             id = random.nextLong()
        } while ( data.contains(id) )
        return id;
    }
}

