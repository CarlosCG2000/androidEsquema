package es.upsa.mimo.recyclerview

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import es.upsa.mimo.recyclerview.databinding.ContactoItemBinding

class ContactosAdapter : RecyclerView.Adapter< ContactosAdapter.ContactoViewHolder >()
{
    private var contactos: List<Contacto> = emptyList()

    fun submitList(contactos: List<Contacto>)
    {
        this.contactos = contactos
        notifyDataSetChanged()
    }


    override fun getItemCount(): Int
    {
        return contactos.size
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ContactoViewHolder
    {
        val layoutInflater = LayoutInflater.from( parent.context )
        val itemBinding : ContactoItemBinding = ContactoItemBinding.inflate(layoutInflater, parent, false )
        return ContactoViewHolder( itemBinding )
    }


    override fun onBindViewHolder(holder: ContactoViewHolder, position: Int)
    {
        val contacto = contactos.get( position )
        holder.bind(contacto)
    }




    class ContactoViewHolder(val itemBinding: ContactoItemBinding): RecyclerView.ViewHolder(itemBinding.root)
    {

        fun bind(contacto: Contacto)
        {
            itemBinding.tvNombre.text = contacto.nombre
            itemBinding.tvEmail.text = contacto.email
            itemBinding.tvTelefono.text = contacto.telefono
        }

    }


}