package es.upsa.mimo.recyclerview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.activity.viewModels
import androidx.core.os.bundleOf
import es.upsa.mimo.recyclerview.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity()
{
    val viewModel: MainViewModel by viewModels {
                                                  val repository: Repository = ContactoRepository()
                                                  val defaultArgs: Bundle = bundleOf()
                                                  MainViewModel.factory(this, repository, defaultArgs)
                                               }
    lateinit var viewBinding: ActivityMainBinding
    val adapter : ContactosAdapter = ContactosAdapter()

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        viewBinding = ActivityMainBinding.inflate( layoutInflater )
        setContentView( viewBinding.root )

        val contactos = viewModel.findContactos()

        viewBinding.rvContactos.adapter = this.adapter
        this.adapter.submitList( contactos )

    }
}