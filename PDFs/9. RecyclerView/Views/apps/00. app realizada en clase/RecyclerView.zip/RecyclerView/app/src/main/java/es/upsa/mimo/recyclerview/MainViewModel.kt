package es.upsa.mimo.recyclerview

import android.os.Bundle
import androidx.lifecycle.AbstractSavedStateViewModelFactory
import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.savedstate.SavedStateRegistryOwner

class MainViewModel(private val savedStateHandle: SavedStateHandle, private val repository: Repository) : ViewModel()
{


    fun findContactos() : List<Contacto>
    {
        return repository.findAll();
    }




    companion object
    {
        fun factory(owner: SavedStateRegistryOwner, repositoty: Repository, defaultArgs: Bundle?): ViewModelProvider.Factory = object : AbstractSavedStateViewModelFactory(owner, defaultArgs)
                                                                                                       {
                                                                                                           override fun <T : ViewModel> create(key: String, modelClass: Class<T>, handle: SavedStateHandle) : T
                                                                                                           {
                                                                                                               return MainViewModel(handle, repositoty) as T
                                                                                                           }

                                                                                                       }
    }

}