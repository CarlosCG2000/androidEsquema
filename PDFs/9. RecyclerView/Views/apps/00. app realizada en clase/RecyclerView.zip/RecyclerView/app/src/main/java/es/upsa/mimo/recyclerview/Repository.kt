package es.upsa.mimo.recyclerview

import kotlinx.coroutines.flow.Flow

interface Repository {

  fun findAll() : List<Contacto>
  fun findById(id: Long): Contacto?
  fun findAllAsFlow(): Flow<List<Contacto>>
  fun insertContacto(contacto: Contacto): Contacto
  fun updateContacto(contacto: Contacto): Contacto?
}