package es.upsa.mimo.filmstmdb

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import es.upsa.mimo.filmstmdb.databinding.FilmItemBinding
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.Locale

class FilmsAdapter : RecyclerView.Adapter<FilmViewHolder>()
{
    private var films: List<Film> = emptyList()

    fun updateFilms(films: List<Film>)
    {
        this.films = films
        notifyDataSetChanged()
    }

    override fun getItemCount(): Int
    {
        return films.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FilmViewHolder
    {
        val layoutInflater = LayoutInflater.from(parent.context)
        val filmItemBinding = FilmItemBinding.inflate(layoutInflater, parent, false)
        return FilmViewHolder( filmItemBinding )
    }

    override fun onBindViewHolder(holder: FilmViewHolder, position: Int)
    {
        holder.bind( films[position] )
    }


}

class FilmViewHolder(val viewBinding: FilmItemBinding) : RecyclerView.ViewHolder( viewBinding.root )
{
    val dateFormatter = DateTimeFormatter.ofLocalizedDate( FormatStyle.MEDIUM ).withLocale( Locale.getDefault() )
    val context = viewBinding.root.context

    fun bind(film: Film)
    {
        Glide.with( viewBinding.iv.context )
             .load( film.poster )
             .into( viewBinding.iv )
        viewBinding.tvTitle.text    = film.originalName
        viewBinding.tvDirector.text = context.getString(R.string.director_and_date, film.director, dateFormatter.format( film.firstAirDate ))
        viewBinding.tvRating.text   = context.getString(R.string.rating, film.voteAverage)
    }
}



