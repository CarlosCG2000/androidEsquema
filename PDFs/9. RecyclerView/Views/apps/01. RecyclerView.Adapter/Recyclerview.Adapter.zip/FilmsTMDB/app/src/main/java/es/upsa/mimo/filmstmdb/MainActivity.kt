package es.upsa.mimo.filmstmdb

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import es.upsa.mimo.filmstmdb.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity()
{
    val viewModel: MainViewModel by viewModels() {
                                                     val filmsRepository = FilmsRepository()
                                                     MainViewModel.factory( filmsRepository )
                                                 }
    lateinit var viewBinding: ActivityMainBinding
    val filmsAdapter = FilmsAdapter()

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        viewBinding = ActivityMainBinding.inflate( layoutInflater )
        setContentView( viewBinding.root )

        viewBinding.rvFilms.adapter = filmsAdapter
        filmsAdapter.updateFilms( viewModel.queryFilms() )
    }


}