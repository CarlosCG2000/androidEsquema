package es.upsa.mimo.filmstmdb

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.createSavedStateHandle
import androidx.lifecycle.viewmodel.CreationExtras

class MainViewModel(val filmsRepository: FilmsRepository, savedStateHandle: SavedStateHandle) : ViewModel()
{
    fun queryFilms(): List<Film>
    {
       return filmsRepository.queryFilms()
    }


    companion object
    {
        fun factory(filmsRepository: FilmsRepository) : ViewModelProvider.Factory = object : ViewModelProvider.Factory
        {
            override fun <T : ViewModel> create(modelClass: Class<T>, extras: CreationExtras): T
            {
                val savedStateHandle = extras.createSavedStateHandle()
                return MainViewModel(filmsRepository, savedStateHandle) as T
            }
        }
    }
}
