package es.upsa.mimo.filmstmdb

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import es.upsa.mimo.filmstmdb.databinding.ActivityMainBinding
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity()
{
    val viewModel: MainViewModel by viewModels() {
                                                     val filmsRepository = FilmsRepository()
                                                     MainViewModel.factory( filmsRepository )
                                                 }
    lateinit var viewBinding: ActivityMainBinding
    val filmsAdapter = FilmsAdapter()

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)

        viewBinding = ActivityMainBinding.inflate( layoutInflater )
        viewBinding.rvFilms.adapter = filmsAdapter

        lifecycleScope.launch {
             repeatOnLifecycle( Lifecycle.State.STARTED ) {
                 viewModel.films.collect { filmsAdapter.submitList(it) }
             }
        }

        setContentView( viewBinding.root )
        viewModel.queryFilms()
    }



}