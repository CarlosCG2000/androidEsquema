package es.upsa.mimo.filmstmdb

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import es.upsa.mimo.filmstmdb.databinding.FilmItemBinding
import es.upsa.mimo.filmstmdb.databinding.YearItemBinding
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.Locale

class FilmsAdapter : ListAdapter<Item, ItemViewHolder>(FilmsAdapter.DIFF)
{
    override fun getItemViewType(position: Int): Int
    {
        return when ( getItem(position) )
        {
            is   Item.FilmItem -> R.layout.film_item
            else               -> R.layout.year_item
        }
    }


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder
    {
        val layoutInflater = LayoutInflater.from(parent.context)
        return when(viewType)
               {
                  R.layout.film_item -> {
                                          val filmItemBinding = FilmItemBinding.inflate(layoutInflater, parent, false)
                                          FilmItemViewHolder( filmItemBinding )
                                        }
                  else               -> {
                                          val yearItemBinding = YearItemBinding.inflate(layoutInflater, parent, false)
                                          YearItemViewHolder( yearItemBinding )
                                        }
               }
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int)
    {
        holder.bind( getItem(position) )
    }


    companion object
    {
        val DIFF: DiffUtil.ItemCallback<Item> = object : DiffUtil.ItemCallback<Item>()
                                                {
                                                    override fun areItemsTheSame(oldItem: Item, newItem: Item): Boolean
                                                    {
                                                        return when
                                                               {
                                                                   (oldItem is Item.FilmItem) && (newItem is Item.FilmItem) -> oldItem.film.id == newItem.film.id
                                                                   (oldItem is Item.YearItem) && (newItem is Item.YearItem) -> oldItem.year == newItem.year
                                                                   else                                                     -> false
                                                               }
                                                    }

                                                    override fun areContentsTheSame(oldItem: Item, newItem: Item): Boolean
                                                    {
                                                        return when
                                                        {
                                                            (oldItem is Item.FilmItem) && (newItem is Item.FilmItem) -> oldItem.film == newItem.film
                                                            (oldItem is Item.YearItem) && (newItem is Item.YearItem) -> oldItem.year == newItem.year
                                                            else                                                     -> false
                                                        }
                                                    }

                                               }
    }
}

class FilmViewHolder(val viewBinding: FilmItemBinding) : RecyclerView.ViewHolder( viewBinding.root )
{
    val dateFormatter = DateTimeFormatter.ofLocalizedDate( FormatStyle.MEDIUM ).withLocale( Locale.getDefault() )
    val context = viewBinding.root.context

    fun bind(film: Film)
    {
        Glide.with( viewBinding.iv.context )
             .load( film.poster )
             .into( viewBinding.iv )
        viewBinding.tvTitle.text = film.originalName
        viewBinding.tvDirector.text = context.getString(R.string.director_and_date, film.director, dateFormatter.format( film.firstAirDate ))
        viewBinding.tvRating.text = context.getString(R.string.rating, film.voteAverage)
    }
}

abstract class ItemViewHolder(val view: View) : RecyclerView.ViewHolder(view)
{
    val dateFormatter = DateTimeFormatter.ofLocalizedDate( FormatStyle.MEDIUM ).withLocale( Locale.getDefault() )
    val context = view.context

    abstract fun bind(item: Item)
}

class FilmItemViewHolder(val viewBinding: FilmItemBinding) : ItemViewHolder( viewBinding.root )
{
    override fun bind(item: Item)
    {
        val film = (item as Item.FilmItem).film
        Glide.with( viewBinding.iv.context )
             .load( film.poster )
             .into( viewBinding.iv )
        viewBinding.tvTitle.text = film.originalName
        viewBinding.tvDirector.text = context.getString(R.string.director_and_date, film.director, dateFormatter.format( film.firstAirDate ))
        viewBinding.tvRating.text = context.getString(R.string.rating, film.voteAverage)
    }
}

class YearItemViewHolder(val viewBinding: YearItemBinding) : ItemViewHolder(viewBinding.root)
{
    override fun bind(item: Item)
    {
        val yearItem = item as Item.YearItem
        viewBinding.year.text = context.getString(R.string.year, yearItem.year)
        viewBinding.count.text = context.resources.getQuantityString(R.plurals.number_of_films, yearItem.count, yearItem.count)
    }
}


