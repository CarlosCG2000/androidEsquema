package es.upsa.mimo.filmstmdb

import android.net.Uri
import android.widget.ImageView
import androidx.databinding.BindingAdapter
import androidx.databinding.BindingConversion
import com.bumptech.glide.Glide
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.Locale


@BindingAdapter("imageUrl")
fun ImageView.setImageUrl(url: String)
{
    Glide.with(this)
         .load( Uri.parse(url) )
         .fallback( android.R.drawable.picture_frame )
         .error( android.R.drawable.picture_frame )
         .placeholder( android.R.drawable.picture_frame )
         .into(this)
}


object Converters {

    @BindingConversion
    @JvmStatic fun toString(value: Int): String
    {
        return value.toString()
    }

    @BindingConversion
    @JvmStatic fun toString(value: LocalDate): String
    {
        val dateTimeFormatter = DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM).withLocale(Locale.getDefault())
        return dateTimeFormatter.format( value )
    }

    @BindingConversion
    @JvmStatic fun toClass(value: String): Class<*>
    {
        return Class.forName( value )
    }
}