package es.upsa.mimo.filmstmdb

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import java.time.LocalDate
import java.util.EnumSet

class FilmsRepository {

    private val films = mutableMapOf<Long, Film>().apply {
        put(1,  Film(1L,  "The Godfather",                     "https://m.media-amazon.com/images/M/MV5BM2MyNjYxNmUtYTAwNi00MTYxLWJmNWYtYzZlODY3ZTk3OTFlXkEyXkFqcGdeQXVyNzkwMjQ5NzM@._V1_SX300.jpg",         "Francis Ford Coppola", "An organized crime dynasty's aging patriarch transfers control of his clandestine empire to his reluctant son.",                                                                            9.2, EnumSet.of(Genre.DRAMA, Genre.CRIME),                    LocalDate.of(1972, 10, 20)) )
        put(2,  Film(2L,  "Red River",                         "https://m.media-amazon.com/images/M/MV5BNTZjN2M2NzgtM2Q4Yy00ZGQ2LWIyOTItNzg2M2ZjN2Y2ODZjXkEyXkFqcGdeQXVyNzA4ODc3ODU@._V1_FMjpg_UX1000_.jpg", "Howard Hawks",         "Dunson leads a cattle drive, the culmination of over 14 years of work, to its destination in Missouri. But his tyrannical behavior along the way causes a mutiny, led by his adopted son.", 7.8, EnumSet.of(Genre.DRAMA, Genre.WESTERN),                  LocalDate.of(1948, 9, 17)) )
        put(3,  Film(3L,  "The Searchers",                     "https://m.media-amazon.com/images/M/MV5BYWQ3YWJiMDEtMDBhNS00YjY1LTkzNmEtY2U4Njg4MjQ3YWE3XkEyXkFqcGdeQXVyNzkwMjQ5NzM@._V1_SX300.jpg",         "John Ford",            "An American Civil War veteran embarks on a journey to rescue his niece from the Comanches",                                                                                                 7.7, EnumSet.of(Genre.DRAMA, Genre.WESTERN, Genre.ADVENTURE), LocalDate.of(1956, 5, 26) ) )
        put(4,  Film(4L,  "The Quiet Man",                     "https://m.media-amazon.com/images/M/MV5BMWM1ZDhlM2MtNDNmMi00MDk4LTg5MjgtODE4ODk1MjYxOTIwXkEyXkFqcGdeQXVyNjc0MzMzNjA@._V1_SX300.jpg",         "John Ford",            "A retired American boxer returns to the village of his birth in Ireland, where he falls for a spirited redhead whose brother is contemptuous of their union.",                              7.7, EnumSet.of(Genre.COMEDY, Genre.DRAMA, Genre.ROMANCE),    LocalDate.of(1952, 11, 8)) )
        put(5,  Film(5L,  "Tiovivo c. 1950",                   "https://m.media-amazon.com/images/M/MV5BMmMyNzg3OTctYTA0MS00NzljLTljZTUtYWQ0M2E2OGRiNTgxXkEyXkFqcGdeQXVyMTA0MjU0Ng@@._V1_SX300.jpg",         "José Luis Garci",      "Madrid, the capital of Spain in the 50s, it is still in a latent postwar period. A carousel of several survivors try to make a living in a gloomy country.",                                6.4, EnumSet.of(Genre.COMEDY, Genre.CRIME, Genre.DRAMA),      LocalDate.of(2004, 10, 1)) )
        put(6,  Film(6L,  "The Man Who Shot Liberty Valance",  "https://m.media-amazon.com/images/M/MV5BMGEyNzhkYzktMGMyZS00YzRiLWJlYjktZjJkOTU5ZDY0ZGI4XkEyXkFqcGdeQXVyNjUwNzk3NDc@._V1_SX300.jpg",         "John Ford",            "A senator returns to a western town for the funeral of an old friend and tells the story of his origins.",                                                                                  8.1, EnumSet.of(Genre.DRAMA, Genre.WESTERN),                  LocalDate.of(1962, 4, 22)) )
        put(7,  Film(7L,  "Cabaret",                           "https://m.media-amazon.com/images/I/71LH1wV9QdL.jpg",                                                                                        "Bob Fosse",            "A female girlie club entertainer in Weimar Republic era Berlin romances two men while the Nazi Party rises to power around them.",                                                          7.7, EnumSet.of(Genre.DRAMA, Genre.MUSICAL),                  LocalDate.of(1972, 2, 13)) )
        put(8,  Film(8L,  "Sleuth",                            "https://m.media-amazon.com/images/I/51SYaxKePmL._AC_UF894,1000_QL80_.jpg",                                                                   "Joseph L. Mankiewicz", "Un hombre que ama los juegos y el teatro invita al amante de su esposa a conocerlo, preparando una batalla de ingenio con resultados potencialmente mortales.",                             7.9, EnumSet.of(Genre.CRIME, Genre.THRILLER),                 LocalDate.of(1972, 5, 5)) )
        put(9,  Film(9L,  "The Treasure of the Sierra Madre",  "https://m.media-amazon.com/images/I/71-nJBDs0JL._AC_SY879_.jpg",                                                                             "John Huston",          "Dos estadounidenses sin suerte, que buscan trabajo en el México de los años 20, convencen a un viejo minero para que les ayude a extraer oro en las montañas de Sierra Madre.",             7.8, EnumSet.of(Genre.CRIME, Genre.THRILLER),                 LocalDate.of(1948, 1, 24)) )
        put(10, Film(10L, "High Noon",                         "https://m.media-amazon.com/images/I/51zACY0KCSL._AC_UF894,1000_QL80_.jpg",                                                                   "Fred Zinnemann",       "Un marshal, a pesar del desacuerdo de su recién casada y de la gente del pueblo, debe enfrentarse solo a una banda de asesinos cuando su líder llegue en el tren del mediodía.",            8.0, EnumSet.of(Genre.WESTERN, Genre.DRAMA),                  LocalDate.of(1952, 3, 2)) )
        put(11, Film(11L, "Lawrance of Arabia",                "https://m.media-amazon.com/images/I/71QOw-ZFjoL._AC_UF894,1000_QL80_.jpg",                                                                   "David Lean",           "El Cairo, 1917. Durante la Gran Guerra (1914-1918), T.E. Lawrence, un oficial británico, es enviado al desierto para participar en una campaña de apoyo a los árabes contra Turquía. Los nativos adoran a Lawrence porque ha demostrado sobradamente ser un amante del desierto y del pueblo árabe. En cambio, sus superiores británicos creen que se ha vuelto loco. A pesar de que los planes de Lawrence se ven coronados por el éxito, su sueño de una Arabia independiente fracasará.", 8.3, EnumSet.of(Genre.DRAMA, Genre.ADVENTURE), LocalDate.of(1962, 10, 1)) )
    }


    public suspend fun queryFilms() : Flow<List<Film>>
    {
        Thread.sleep(1000L)
        return flow {
                       emit( films.values.toList() )
                    }

    }


}