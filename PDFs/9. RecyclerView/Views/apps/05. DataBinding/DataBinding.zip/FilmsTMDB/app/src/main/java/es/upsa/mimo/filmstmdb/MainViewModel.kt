package es.upsa.mimo.filmstmdb

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.createSavedStateHandle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.CreationExtras
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(val filmsRepository: FilmsRepository, savedStateHandle: SavedStateHandle) : ViewModel()
{
    private var _films: MutableStateFlow< List<Film> > = MutableStateFlow( emptyList() )
    val films: StateFlow< List<Item> > = _films.map { list -> list.sortedBy { it.firstAirDate.year } }
                                               .map { list -> list.map { Item.FilmItem(it) } }
                                               .map { list -> list.groupBy { item -> item.film.firstAirDate.year } }
                                               .map { map -> val items = mutableListOf<Item>()
                                                             map.forEach { year, list -> items.add(Item.YearItem(year, list.size))
                                                                                         items.addAll(list)
                                                                         }
                                                             items
                                                    }
                                               .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun queryFilms()
    {
        viewModelScope.launch {
                                  filmsRepository.queryFilms()
                                                 .collect { _films.emit( it ) }
                              }
    }


    companion object
    {
        fun factory(filmsRepository: FilmsRepository) : ViewModelProvider.Factory = object : ViewModelProvider.Factory
        {
            override fun <T : ViewModel> create(modelClass: Class<T>, extras: CreationExtras): T
            {
                val savedStateHandle = extras.createSavedStateHandle()
                return MainViewModel(filmsRepository, savedStateHandle) as T
            }
        }
    }
}

sealed class Item()
{
    class FilmItem(val film: Film) : Item()
    class YearItem(val year: Int, val count: Int): Item()
}