package es.upsa.mimo.filmstmdb

import android.net.Uri
import android.widget.ImageView
import androidx.databinding.BindingAdapter
import androidx.databinding.BindingConversion
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.Locale


@BindingAdapter(value=["listAdapter", "items"], requireAll = true)
fun <T, I> RecyclerView.setListAdapterAndItems(listAdapterClass: Class<T>, items: List<I>)
{
//    var listAdapter : ListAdapter<I, RecyclerView.ViewHolder>? = null
//    if ( this.adapter == null )
//    {
//        listAdapter = listAdapterClass.getConstructor().newInstance() as ListAdapter<I, RecyclerView.ViewHolder>
//        this.adapter = listAdapter
//    }
//    else listAdapter = this.adapter as ListAdapter<I, RecyclerView.ViewHolder>
//    listAdapter.submitList( items )

    var listAdapter = this.adapter?.let { it as ListAdapter<I, RecyclerView.ViewHolder> } ?: (listAdapterClass.getConstructor().newInstance() as ListAdapter<I, RecyclerView.ViewHolder>).also { this.adapter = it}
    listAdapter.submitList( items )
}


@BindingAdapter("imageUrl")
fun ImageView.setImageUrl(url: String)
{
    Glide.with(this)
         .load( Uri.parse(url) )
         .fallback( android.R.drawable.picture_frame )
         .error( android.R.drawable.picture_frame )
         .placeholder( android.R.drawable.picture_frame )
         .into(this)
}


object Converters {

    @BindingConversion
    @JvmStatic fun toString(value: Int): String
    {
        return value.toString()
    }

    @BindingConversion
    @JvmStatic fun toString(value: LocalDate): String
    {
        val dateTimeFormatter = DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM).withLocale(Locale.getDefault())
        return dateTimeFormatter.format( value )
    }

    @BindingConversion
    @JvmStatic fun toClass(value: String): Class<*>
    {
        return Class.forName( value )
    }
}