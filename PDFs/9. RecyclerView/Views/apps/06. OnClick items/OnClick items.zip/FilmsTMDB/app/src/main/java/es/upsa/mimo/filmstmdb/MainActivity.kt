package es.upsa.mimo.filmstmdb

import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import es.upsa.mimo.filmstmdb.databinding.ActivityMainBinding
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity()
{
    val viewModel: MainViewModel by viewModels() {
                                                     val filmsRepository = FilmsRepository()
                                                     MainViewModel.factory( filmsRepository )
                                                 }
    lateinit var viewBinding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        viewBinding = DataBindingUtil.setContentView(this, R.layout.activity_main)

        viewBinding.viewModel = this.viewModel
        viewBinding.lifecycleOwner = this

        viewModel.queryFilms()

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.events.collect {
                    when(it)
                    {
                        is Event.OnClickFilm -> Toast.makeText(this@MainActivity, "onClick ${it.film.originalName}", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }

    }
}