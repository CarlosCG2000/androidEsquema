package es.upsa.mimo.filmstmdb

import java.time.LocalDate
import java.util.EnumSet

data class Film (var id: Long, var originalName: String, var poster : String, var director: String, var plot: String, var voteAverage: Double, var tags: EnumSet<Genre>, val firstAirDate: LocalDate)
enum class Genre
{
    DRAMA, WESTERN, COMEDY, CRIME, ADVENTURE, ROMANCE, MUSICAL, THRILLER;
}
