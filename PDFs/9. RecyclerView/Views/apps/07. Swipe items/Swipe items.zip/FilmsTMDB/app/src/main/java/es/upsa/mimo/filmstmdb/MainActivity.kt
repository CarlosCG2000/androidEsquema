package es.upsa.mimo.filmstmdb

import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import es.upsa.mimo.filmstmdb.databinding.ActivityMainBinding
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity()
{
    val viewModel: MainViewModel by viewModels() {
                                                     val filmsRepository = FilmsRepository()
                                                     MainViewModel.factory( filmsRepository )
                                                 }
    lateinit var viewBinding: ActivityMainBinding
    val adapter: ItemsAdapter = ItemsAdapter()

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        viewBinding = ActivityMainBinding.inflate(layoutInflater)
        setContentView( viewBinding.root )

        viewBinding.rvFilms.adapter = adapter

        lifecycleScope.launch {
                                repeatOnLifecycle(Lifecycle.State.STARTED)
                                {
                                    viewModel.films.collect { adapter.submitList( it ) }
                                }
                              }
        viewModel.queryFilms()
    }
}


