package es.upsa.mimo.filmstmdb

import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import androidx.constraintlayout.motion.widget.MotionLayout
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import es.upsa.mimo.filmstmdb.databinding.FilmItemBinding
import es.upsa.mimo.filmstmdb.databinding.YearItemBinding

class ItemsAdapter : ListAdapter<Item, ItemViewHolder>( DIFF )
{
    override fun getItemViewType(position: Int): Int
    {
        return when ( getItem(position) )
               {
                  is   Item.FilmItem -> R.layout.film_item
                  else               -> R.layout.year_item
               }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder
    {
        val layoutInflater = LayoutInflater.from(parent.context)
        return when(viewType)
               {
                  R.layout.film_item -> {
                                          val filmItemBinding = FilmItemBinding.inflate(layoutInflater, parent, false)
                                          FilmItemViewHolder( filmItemBinding )
                                        }
                  else               -> {
                                          val yearItemBinding = YearItemBinding.inflate(layoutInflater, parent, false)
                                          YearItemViewHolder( yearItemBinding )
                                        }
               }


    }

    override fun onViewDetachedFromWindow(holder: ItemViewHolder)
    {
        super.onViewDetachedFromWindow(holder)
        if (holder is MotionItemViewHolder) holder.reset()
    }

    override fun onViewRecycled(holder: ItemViewHolder)
    {
        super.onViewRecycled(holder)
        if (holder is MotionItemViewHolder) holder.reset()
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int)
    {
        holder.bind( getItem(position) )
    }

    companion object {

        val DIFF: DiffUtil.ItemCallback<Item> = object : DiffUtil.ItemCallback<Item>() {

            override fun areItemsTheSame(oldItem: Item, newItem: Item): Boolean
            {
                return when
                       {
                           (oldItem is Item.FilmItem) && (newItem is Item.FilmItem) -> oldItem.film.id == newItem.film.id
                           (oldItem is Item.YearItem) && (newItem is Item.YearItem) -> oldItem.year == newItem.year
                           else                                                     -> false
                       }
            }

            override fun areContentsTheSame(oldItem: Item, newItem: Item): Boolean
            {
                return when
                {
                    (oldItem is Item.FilmItem) && (newItem is Item.FilmItem) -> oldItem.film == newItem.film
                    (oldItem is Item.YearItem) && (newItem is Item.YearItem) -> oldItem.year == newItem.year
                    else                                                     -> false
                }
            }

        }
    }

}

abstract class ItemViewHolder(val view: View) : RecyclerView.ViewHolder(view)
{
    abstract fun bind(item: Item)
}

abstract class MotionItemViewHolder(val v: View) : ItemViewHolder(v)
{
    abstract fun reset()
}

interface Action
{
    fun perform( action : () -> Unit  ) : Unit
}

class FilmItemViewHolder(val dataBinding: FilmItemBinding) : MotionItemViewHolder( dataBinding.root )
{

    init {
            dataBinding.action = object : Action {
                                                    override fun perform(action: () -> Unit)
                                                    {
                                                        reset()
                                                        action.invoke()
                                                    }
                                                 }
         }


    override fun bind(item: Item)
    {
        dataBinding.filmItem = item as Item.FilmItem
        dataBinding.executePendingBindings()
    }

    override fun reset()
    {
        (dataBinding.root as MotionLayout).transitionToStart()
    }

}

class YearItemViewHolder(val dataBinding: YearItemBinding) : ItemViewHolder(dataBinding.root)
{
    override fun bind(item: Item)
    {
        dataBinding.data = item as Item.YearItem
        dataBinding.executePendingBindings()
    }
}

