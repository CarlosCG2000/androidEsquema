package es.upsa.mimo.filmstmdb

import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.snackbar.Snackbar
import es.upsa.mimo.filmstmdb.databinding.ActivityMainBinding
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity()
{
    val viewModel: MainViewModel by viewModels() {
                                                     val filmsRepository = FilmsRepository()
                                                     MainViewModel.factory( filmsRepository )
                                                 }
    lateinit var viewBinding: ActivityMainBinding
    val adapter: ItemsAdapter = ItemsAdapter()

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        viewBinding = ActivityMainBinding.inflate( layoutInflater )
        setContentView( viewBinding.root )

        viewBinding.rvFilms.adapter = adapter


        lifecycleScope.launch {
                                 repeatOnLifecycle(Lifecycle.State.STARTED)
                                 {
                                    viewModel.films.collect { adapter.submitList( it ) }
                                 }
                              }


        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED)
            {
                viewModel.events.collect {
                    when(it)
                    {
                        is Event.OnFilmEdit    -> Toast.makeText(this@MainActivity, "onEdit ${it.film.originalName}", Toast.LENGTH_SHORT).show()
                        is Event.OnFilmRemoved -> Snackbar.make(viewBinding.root, "Se ha elimianado el film ${it.film.originalName}", Snackbar.LENGTH_LONG)
                                                          .setAction(R.string.undo) { v -> viewModel.addFilm( it.film ) }
                                                          .show()
                    }
                }
            }
        }

        viewModel.queryFilms()


    }
}


