package es.upsa.mimo.filmstmdb

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.createSavedStateHandle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.CreationExtras
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(val filmsRepository: FilmsRepository, savedStateHandle: SavedStateHandle) : ViewModel()
{
    private var _films: MutableStateFlow< List<Film> > = MutableStateFlow( emptyList() )
    val films: StateFlow< List<Item> > = _films.map { list -> list.sortedBy { it.firstAirDate.year } }
                                               .map { list -> list.map { film -> createFilmItem(film) } }
                                               .map { list -> list.groupBy { item -> item.film.firstAirDate.year } }
                                               .map { map -> val items = mutableListOf<Item>()
                                                             map.forEach { year, list -> items.add(Item.YearItem(year, list.size))
                                                                                         items.addAll(list)
                                                                         }
                                                             items
                                                    }
                                               .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())


    private val _events: MutableSharedFlow<Event> = MutableSharedFlow()
    val events: SharedFlow<Event> = _events.asSharedFlow()

    fun queryFilms()
    {
        viewModelScope.launch {
                                    filmsRepository.queryFilms()
                                                   .collect { _films.emit( it ) }
                              }
    }


    private fun onEditFilm(film: Film)
    {
        viewModelScope.launch { _events.emit( Event.OnFilmEdit(film) ) }

    }

    private fun onRemoveFilm(film: Film)
    {
        viewModelScope.launch { filmsRepository.removeFilm(film.id)
                                                                .collect { _events.emit(Event.OnFilmRemoved(film)) }
                              }
    }


    fun addFilm(film: Film)
    {
        viewModelScope.launch {
                                 filmsRepository.addFilm(film)
                              }
    }

    private fun createFilmItem(film: Film) :  Item.FilmItem
    {
        return Item.FilmItem(film, { onEditFilm(film) }, { onRemoveFilm(film) } )
    }

    companion object
    {
        fun factory(filmsRepository: FilmsRepository) : ViewModelProvider.Factory = object : ViewModelProvider.Factory
        {
            override fun <T : ViewModel> create(modelClass: Class<T>, extras: CreationExtras): T
            {
                val savedStateHandle = extras.createSavedStateHandle()
                return MainViewModel(filmsRepository, savedStateHandle) as T
            }
        }
    }
}

sealed interface Item
{
    class FilmItem(val film: Film, val onEdit : () -> Unit, val onRemove : () -> Unit) : Item
    {
        fun edit()   { onEdit.invoke() }
        fun remove() { onRemove.invoke() }
    }
    class YearItem(val year: Int, val count: Int): Item
}

sealed interface Event
{
    class OnFilmEdit(val film: Film): Event
    class OnFilmRemoved(val film: Film): Event
}