package es.upsa.mimo.filmstmdb

import java.time.LocalDate
import java.util.EnumSet

data class Film (val id: Long, val originalName: String, val poster : String, val director: String, val plot: String, val voteAverage: Double, val tags: EnumSet<Genre>, val releaseDate: LocalDate)
enum class Genre
{
    DRAMA, WESTERN, COMEDY, CRIME, ADVENTURE, ROMANCE, MUSICAL, THRILLER;
}
