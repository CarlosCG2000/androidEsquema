package es.upsa.mimo.filmstmdb

import android.app.DatePickerDialog
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.snackbar.BaseTransientBottomBar
import com.google.android.material.snackbar.Snackbar
import es.upsa.mimo.filmstmdb.databinding.ActivityFilmBinding
import kotlinx.coroutines.launch
import java.time.LocalDate

class FilmActivity : AppCompatActivity(), PosterDialog.OnPosterWatcherListener {

    companion object
    {
        val EXTRA_ID     = "es.upsa.mimo.filmstmdb.extras.ID"
        val EXTRA_ACTION = "es.upsa.mimo.filmstmdb.extras.ACTION"

        val ACTION_INSERT = "es.upsa.mimo.filmstmdb.extras.ACTION.insert"
        val ACTION_UPDATE = "es.upsa.mimo.filmstmdb.extras.ACTION.update"
    }


    private lateinit var dataBinding: ActivityFilmBinding
    val viewModel: FilmActivityViewModel by viewModels { FilmActivityViewModel.factory }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        dataBinding = DataBindingUtil.setContentView(this, R.layout.activity_film)

        dataBinding.viewModel = viewModel
        dataBinding.lifecycleOwner = this

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.CREATED)
            {
                viewModel.events.collect {
                                               when ( it )
                                               {
                                                   is FilmEvent.FilmError                  -> onFilmError(it.message)
                                                   is FilmEvent.FilmInserted               -> onFilmSaved(it.film) { viewModel.newFilm()        }
                                                   is FilmEvent.FilmUpdated                -> onFilmSaved(it.film) { this@FilmActivity.finish() }
                                                   is FilmEvent.ChangeReleaseDateRequested -> onChangeReleaseDate( it.date )
                                                   is FilmEvent.ChangePosterRequested      -> onChangePoster()
                                               }
                                            }
            }
        }

    }

    private fun onChangePoster()
    {
        val posterDialog = PosterDialog()
        posterDialog.show(supportFragmentManager, PosterDialog::class.simpleName)
    }

    private fun onFilmError(message: String?)
    {
        Snackbar.make(dataBinding.root, message ?: "Error", Snackbar.LENGTH_LONG).show()
    }

    private fun onFilmSaved(film: Film, onTimeOutLister: (()-> Unit)? = null)
    {
        val snakebar = Snackbar.make(dataBinding.root, "Pelicula almacenada", Snackbar.LENGTH_LONG)
                               .setAction(R.string.undo) { viewModel.undoSaveFilm(film) }
        if (onTimeOutLister != null)
        {
            snakebar.addCallback( object: BaseTransientBottomBar.BaseCallback<Snackbar>()
                                  {
                                      override fun onDismissed(transientBottomBar: Snackbar?, event: Int)
                                      {
                                          super.onDismissed(transientBottomBar, event)
                                          when (event)
                                          {
                                              DISMISS_EVENT_TIMEOUT -> onTimeOutLister.invoke()
                                          }
                                      }
                                 })
        }
        snakebar.show()
    }


    private fun onChangeReleaseDate(date: LocalDate)
    {
         val datePickerDialog = DatePickerDialog( this,
                                                 {_, year, month, day -> viewModel.setReleaseDate(LocalDate.of(year, month, day))},
                                                 date.year,
                                                 date.monthValue,
                                                 date.dayOfMonth)
         datePickerDialog.show()
    }

    override fun onCartelChanged(url: String) {
        viewModel.setPoster(url)
    }


}