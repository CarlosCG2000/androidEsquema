package es.upsa.mimo.filmstmdb

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.createSavedStateHandle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.CreationExtras
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.collect
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.flow.updateAndGet
import kotlinx.coroutines.launch
import java.time.LocalDate
import java.util.EnumSet

class FilmActivityViewModel(val repository: FilmsRepository, val savedStateHandle: SavedStateHandle) : ViewModel()
{
    lateinit var action: String
    var originalFilm : MutableStateFlow<Film> = MutableStateFlow(defaultFilm)
    val film: MutableStateFlow<FilmUI> = MutableStateFlow( defaultFilm.asFilmUI() )
    val _events = MutableSharedFlow<FilmEvent>()
    val events : SharedFlow<FilmEvent> = _events.asSharedFlow()


    init
    {
        viewModelScope.launch { originalFilm.collect { film.emit( it.asFilmUI() ) } }

        viewModelScope.launch {
            action = savedStateHandle[FilmActivity.EXTRA_ACTION] ?: FilmActivity.ACTION_INSERT
            when ( action  )
            {
                FilmActivity.ACTION_UPDATE -> savedStateHandle.get<Long>(FilmActivity.EXTRA_ID)?.apply {
                                                                                                          repository.queryFilmById(this)
                                                                                                                    .collect {when(it)
                                                                                                                                            {
                                                                                                                                                is Result.Ok    -> originalFilm.emit( it.data )
                                                                                                                                                is Result.Error -> _events.emit( FilmEvent.FilmError(it.message) )
                                                                                                                                            }
                                                                                                                             }
                                                                                                       } ?: _events.emit( FilmEvent.FilmError("The film id is required") )
                FilmActivity.ACTION_INSERT -> originalFilm.emit( defaultFilm )
           }
        }
    }


    companion object
    {
        val factory : ViewModelProvider.Factory = object : ViewModelProvider.Factory
        {
            override fun <T : ViewModel> create(modelClass: Class<T>, extras: CreationExtras): T
            {
                val application = extras[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as FilmsApplication
                val savedStateHandle = extras.createSavedStateHandle()
                return FilmActivityViewModel(application.repository, savedStateHandle) as T
            }
        }

        val defaultFilm : Film = Film(-1L, "", "", "", "", 0.0, EnumSet.noneOf( Genre::class.java ), LocalDate.now())
    }

    public fun newFilm()
    {
        viewModelScope.launch { originalFilm.emit( defaultFilm ) }
    }

    public fun changeReleaseDate()
    {
        viewModelScope.launch { _events.emit( FilmEvent.ChangeReleaseDateRequested(film.value.releaseDate.value) ) }
    }

    public fun changePoster()
    {
        viewModelScope.launch { _events.emit( FilmEvent.ChangePosterRequested ) }
    }

    public fun addTag(tag: Genre): Unit
    {
        film.value.addTag(tag)
    }

    public fun removeTag(tag: Genre): Unit
    {
        film.value.removeTag(tag)
    }

    public fun setReleaseDate(date: LocalDate)
    {
        film.value.releaseDate.value = date
    }

    public fun setPoster(url: String)
    {
        film.value.poster.value = url
    }

    public fun saveFilm()
    {
        viewModelScope.launch {
            val theFilm = film.value.asFilm()
            val flow = when ( action )
                       {
                          FilmActivity.ACTION_INSERT ->  repository.insertFilm( theFilm )
                          else                       ->  repository.updateFilm( theFilm )
                       }

            flow.collect {
                            when(it)
                            {
                                is Result.Ok    -> {
                                                       _events.emit( if ( FilmActivity.ACTION_INSERT == action) FilmEvent.FilmInserted(it.data) else FilmEvent.FilmUpdated(originalFilm.value) )
                                                       originalFilm.emit( it.data )
                                                   }
                                is Result.Error -> _events.emit( FilmEvent.FilmError( it.message ) )
                            }
                         }
        }
    }

    fun undoSaveFilm(theFilm: Film)
    {
        viewModelScope.launch {
            when( action )
            {
                FilmActivity.ACTION_INSERT ->  repository.removeFilm( theFilm.id )
                                                         .collect  {
                                                                      when(it)
                                                                      {
                                                                         is Result.Ok    -> film.emit( theFilm.copy(id = -1L).asFilmUI() )
                                                                         is Result.Error -> _events.emit( FilmEvent.FilmError( it.message ?: "Undo error" ) )
                                                                      }
                                                                   }

                FilmActivity.ACTION_UPDATE -> repository.updateFilm( theFilm )
                                                        .collect {
                                                                     when(it)
                                                                     {
                                                                         is Result.Ok    -> originalFilm.update { theFilm }
                                                                         is Result.Error -> _events.emit( FilmEvent.FilmError( it.message ?: "Undo error" ) )
                                                                     }
                                                                 }

            }
        }
    }

}

sealed interface FilmEvent
{
    class FilmInserted(val film: Film): FilmEvent
    class FilmUpdated(val film: Film): FilmEvent
    class FilmError(val message: String?) : FilmEvent
    class ChangeReleaseDateRequested(val date: LocalDate): FilmEvent
    object ChangePosterRequested: FilmEvent
}



class FilmUI (val id: Long, var originalName: String, val poster : MutableStateFlow<String>, var director: String, var plot: String, val voteAverage: MutableStateFlow<Float>, val tags: MutableStateFlow< EnumSet<Genre> >, val releaseDate: MutableStateFlow<LocalDate>)
{
    fun addTag(tag: Genre) = tags.updateAndGet { EnumSet.copyOf( it ).apply { this.add(tag) } }
    fun removeTag(tag: Genre) = tags.updateAndGet { EnumSet.copyOf( it ).apply { this.remove(tag) } }

    fun asFilm() : Film = Film(id, originalName, poster.value, director, plot, voteAverage.value.toDouble(), tags.value, releaseDate.value)
}

public interface ActionWithTag
{
    fun perform(tag: Genre) : Unit
}

fun Film.asFilmUI(): FilmUI
{
    return FilmUI (id, originalName, MutableStateFlow(poster), director, plot, MutableStateFlow(voteAverage.toFloat()), MutableStateFlow( EnumSet.copyOf(tags) ), MutableStateFlow(releaseDate))
}