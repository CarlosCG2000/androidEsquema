package es.upsa.mimo.filmstmdb

import android.net.Uri
import android.widget.ImageView
import android.widget.RatingBar
import androidx.databinding.BindingAdapter
import androidx.databinding.BindingConversion
import androidx.databinding.InverseBindingAdapter
import androidx.databinding.InverseBindingListener
import com.bumptech.glide.Glide
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup
import java.time.LocalDate
import java.time.format.DateTimeFormatter
import java.time.format.FormatStyle
import java.util.EnumSet
import java.util.Locale


@BindingAdapter("imageUrl")
fun ImageView.setImageUrl(url: String)
{
    Glide.with(this)
         .load( Uri.parse(url) )
         .fallback( android.R.drawable.picture_frame )
         .error( android.R.drawable.picture_frame )
         .placeholder( android.R.drawable.picture_frame )
         .into(this)
}


@BindingAdapter(value=["tags", "onClose"], requireAll = false)
fun ChipGroup.bindTags(tags: EnumSet<Genre>, onCloseAction: ActionWithTag): Unit
{
    this.removeAllViewsInLayout()
    val tagLabels = context.resources.getStringArray(R.array.generos)
    tags.forEach { tag -> this.addView( Chip(this.context).apply {
                                                                    isClickable = false
                                                                    text = tagLabels.get( tag.ordinal )
                                                                    if (onCloseAction == null) isCloseIconVisible = false
                                                                    else {
                                                                            isCloseIconVisible = true
                                                                            setOnCloseIconClickListener { v -> onCloseAction.perform(tag) }
                                                                         }
                                                            })
                 }
}

@BindingAdapter(value=["complementTags", "onClick"], requireAll = true)
fun ChipGroup.bindTagsToAdd(complementTags: EnumSet<Genre>, onClickAction: ActionWithTag): Unit
{
    this.removeAllViews()
    val tagLabels = context.resources.getStringArray(R.array.generos)

    EnumSet.complementOf( complementTags )
           .forEach {tag ->  this.addView( Chip(this.context).apply {
                                                                          isClickable = true
                                                                          isCloseIconVisible= false
                                                                          isCheckable = false
                                                                          chipIcon =  context.getDrawable( R.drawable.ic_add )
                                                                          text = tagLabels.get( tag.ordinal )
                                                                          setOnClickListener { v -> onClickAction.perform(tag) }
                                                                    } )
                    }
}

@BindingAdapter(value = ["rating", "app:ratingAttrChanged"], requireAll = false)
fun RatingBar.setRatingPelicula(rating: Float, ratingAttrChanged: InverseBindingListener): Unit
{
    this.setOnRatingBarChangeListener { ratingBar, rating, fromUser ->  if (fromUser == true) ratingAttrChanged.onChange()}
    this.rating = rating / 2
}

@InverseBindingAdapter(attribute = "rating", event = "ratingAttrChanged")
fun RatingBar.getRatingPelicula(): Float
{
    return this.rating * 2
}


object Converters {

    @BindingConversion
    @JvmStatic fun toString(value: Int): String
    {
        return value.toString()
    }

    @BindingConversion
    @JvmStatic fun toString(value: LocalDate): String
    {
        val dateTimeFormatter = DateTimeFormatter.ofLocalizedDate(FormatStyle.MEDIUM).withLocale(Locale.getDefault())
        return dateTimeFormatter.format( value )
    }

    @BindingConversion
    @JvmStatic fun toClass(value: String): Class<*>
    {
        return Class.forName( value )
    }

}