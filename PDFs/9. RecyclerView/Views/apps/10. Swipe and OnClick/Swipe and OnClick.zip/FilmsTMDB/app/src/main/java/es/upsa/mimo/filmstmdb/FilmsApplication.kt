package es.upsa.mimo.filmstmdb

import android.app.Application

class FilmsApplication: Application() {

    val repository : FilmsRepository = FilmsRepository()

    override fun onCreate() {
        super.onCreate()

    }
}