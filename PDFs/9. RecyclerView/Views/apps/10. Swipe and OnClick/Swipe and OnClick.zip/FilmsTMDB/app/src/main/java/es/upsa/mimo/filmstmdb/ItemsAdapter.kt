package es.upsa.mimo.filmstmdb

import android.view.GestureDetector
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import androidx.constraintlayout.motion.widget.MotionLayout
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import es.upsa.mimo.filmstmdb.databinding.FilmItemBinding
import es.upsa.mimo.filmstmdb.databinding.YearItemBinding

class ItemsAdapter() : ListAdapter<Item, ItemViewHolder>( DIFF )
{
    private var onItemClick: ((Item.FilmItem) -> Unit) ? = null;


    fun setOnItemClick(onItemClick: ((Item.FilmItem) -> Unit)?)
    {
        this.onItemClick = onItemClick
    }


    override fun getItemViewType(position: Int): Int
    {
        return when ( getItem(position) )
               {
                  is   Item.FilmItem -> R.layout.film_item
                  else               -> R.layout.year_item
               }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder
    {
        val layoutInflater = LayoutInflater.from(parent.context)
        return when(viewType)
               {
                  R.layout.film_item -> {
                                          val filmItemBinding = FilmItemBinding.inflate(layoutInflater, parent, false)
                                          FilmItemViewHolder( filmItemBinding, onItemClick )
                                        }
                  else               -> {
                                          val yearItemBinding = YearItemBinding.inflate(layoutInflater, parent, false)
                                          YearItemViewHolder( yearItemBinding )
                                        }
               }


    }

    override fun onViewDetachedFromWindow(holder: ItemViewHolder)
    {
        super.onViewDetachedFromWindow(holder)
        if (holder is MotionItemViewHolder) holder.reset()
    }

    override fun onViewRecycled(holder: ItemViewHolder)
    {
        super.onViewRecycled(holder)
        if (holder is MotionItemViewHolder) holder.reset()
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int)
    {
        holder.bind( getItem(position) )
    }

    companion object {

        val DIFF: DiffUtil.ItemCallback<Item> = object : DiffUtil.ItemCallback<Item>() {

            override fun areItemsTheSame(oldItem: Item, newItem: Item): Boolean
            {
                return when
                       {
                           (oldItem is Item.FilmItem) && (newItem is Item.FilmItem) -> oldItem.film.id == newItem.film.id
                           (oldItem is Item.YearItem) && (newItem is Item.YearItem) -> oldItem.year == newItem.year
                           else                                                     -> false
                       }
            }

            override fun areContentsTheSame(oldItem: Item, newItem: Item): Boolean
            {
                return when
                {
                    (oldItem is Item.FilmItem) && (newItem is Item.FilmItem) -> oldItem.film == newItem.film
                    (oldItem is Item.YearItem) && (newItem is Item.YearItem) -> oldItem.year == newItem.year
                    else                                                     -> false
                }
            }

        }
    }

}

abstract class ItemViewHolder(val view: View) : RecyclerView.ViewHolder(view)
{
    abstract fun bind(item: Item)
}

abstract class MotionItemViewHolder(val v: View) : ItemViewHolder(v), View.OnTouchListener
{
    abstract fun reset()
}

interface Action
{
    fun perform( action : () -> Unit  ) : Unit
}

class FilmItemViewHolder(val dataBinding: FilmItemBinding, val onItemClick: ((Item.FilmItem) -> Unit)? ): MotionItemViewHolder( dataBinding.root )
{
    private val gestureDetector = GestureDetector(itemView.context, object : GestureDetector.SimpleOnGestureListener()
                                                                    {
                                                                        override fun onSingleTapUp(e: MotionEvent): Boolean
                                                                        {
                                                                            onItemClick?.apply { invoke( data!! ) }
                                                                            return true
                                                                        }

                                                                        override fun onDown(e: MotionEvent): Boolean
                                                                        {
                                                                            return false
                                                                        }
                                                                    })
    private var data : Item.FilmItem? = null

    init {
            dataBinding.action = object : Action {
                                                    override fun perform(action: () -> Unit)
                                                    {
                                                        reset()
                                                        action.invoke()
                                                    }
                                                 }
            itemView.setOnTouchListener(this)
         }

    override fun bind(item: Item)
    {
        data = item as Item.FilmItem
        dataBinding.filmItem = data
        dataBinding.executePendingBindings()
    }

    override fun reset()
    {
        (dataBinding.root as MotionLayout).transitionToStart()
    }

    override fun onTouch(v: View, event: MotionEvent): Boolean
    {
        gestureDetector.onTouchEvent(event)
        return false
    }

}

class YearItemViewHolder(val dataBinding: YearItemBinding) : ItemViewHolder(dataBinding.root)
{
    override fun bind(item: Item)
    {
        dataBinding.data = item as Item.YearItem
        dataBinding.executePendingBindings()
    }
}







