package es.upsa.mimo.filmstmdb

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.snackbar.Snackbar
import es.upsa.mimo.filmstmdb.databinding.ActivityMainBinding
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity()
{
    val viewModel: MainViewModel by viewModels() { MainViewModel.factory }
    lateinit var dataBinding: ActivityMainBinding
    val adapter: ItemsAdapter = ItemsAdapter()

    override fun onCreate(savedInstanceState: Bundle?)
    {
        super.onCreate(savedInstanceState)
        dataBinding = DataBindingUtil.setContentView(this, R.layout.activity_main)


        adapter.setOnItemClick { filmItem -> filmItem.edit() }
        dataBinding.rvFilms.adapter = adapter
        dataBinding.viewModel = viewModel
        dataBinding.lifecycleOwner = this

        lifecycleScope.launch {
                                 repeatOnLifecycle(Lifecycle.State.STARTED)
                                 {
                                    viewModel.films.collect { adapter.submitList( it ) }
                                 }
                              }


        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED)
            {
                viewModel.events.collect {
                    when(it)
                    {
                        is Event.OnEditFilmRequested    -> startActivity( Intent(this@MainActivity, FilmActivity::class.java).apply {
                                                                                                                                                      putExtra(FilmActivity.EXTRA_ACTION, FilmActivity.ACTION_UPDATE)
                                                                                                                                                      putExtra(FilmActivity.EXTRA_ID, it.film.id)
                                                                                                                                                  } )
                        is Event.OnInsertFilmRequested    -> startActivity( Intent(this@MainActivity, FilmActivity::class.java).apply {
                                                                                                                                                       putExtra(FilmActivity.EXTRA_ACTION, FilmActivity.ACTION_INSERT)
                                                                                                                                                    } )
                        is Event.OnFilmRemoved -> Snackbar.make(dataBinding.root, "Se ha eliminado el film ${it.film.originalName}", Snackbar.LENGTH_LONG)
                                                          .setAction(R.string.undo) { v -> viewModel.undoRemoveFilm( it.film ) }
                                                          .show()
                        is Event.OnError       -> Snackbar.make(dataBinding.root, "Error: ${it.message}", Snackbar.LENGTH_LONG).show()
                    }
                }
            }
        }

        viewModel.queryFilms()


    }
}


