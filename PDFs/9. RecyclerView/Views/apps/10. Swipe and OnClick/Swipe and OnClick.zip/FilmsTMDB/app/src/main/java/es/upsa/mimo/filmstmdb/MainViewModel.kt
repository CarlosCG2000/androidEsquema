package es.upsa.mimo.filmstmdb

import androidx.lifecycle.SavedStateHandle
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.createSavedStateHandle
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.CreationExtras
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(val filmsRepository: FilmsRepository, savedStateHandle: SavedStateHandle) : ViewModel()
{
    private var _films: MutableStateFlow< List<Film> > = MutableStateFlow( emptyList() )
    val films: StateFlow< List<Item> > = _films.map { list -> list.sortedBy { it.releaseDate.year } }
                                               .map { list -> list.map { film -> createFilmItem(film) } }
                                               .map { list -> list.groupBy { item -> item.film.releaseDate.year } }
                                               .map { map -> val items = mutableListOf<Item>()
                                                             map.forEach { year, list -> items.add(Item.YearItem(year, list.size))
                                                                                         items.addAll(list)
                                                                         }
                                                             items
                                                    }
                                               .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())


    private val _events: MutableSharedFlow<Event> = MutableSharedFlow()
    val events: SharedFlow<Event> = _events.asSharedFlow()

    fun queryFilms()
    {
        viewModelScope.launch {
                                    filmsRepository.queryFilms()
                                                   .collect {result -> when(result)
                                                                       {
                                                                           is Result.Ok    -> _films.emit( result.data )
                                                                           is Result.Error -> _events.emit( Event.OnError(result.message) )
                                                                       }

                                                            }
                              }
    }


    private fun onEditFilm(film: Film)
    {
        viewModelScope.launch { _events.emit( Event.OnEditFilmRequested(film) ) }

    }

    public fun onInsertFilm()
    {
        viewModelScope.launch { _events.emit( Event.OnInsertFilmRequested ) }

    }

    private fun removeFilm(film: Film)
    {
        viewModelScope.launch { filmsRepository.removeFilm(film.id)
                                                                .collect { result -> when(result)
                                                                                     {
                                                                                        is Result.Ok    -> _events.emit(Event.OnFilmRemoved(film))
                                                                                        is Result.Error -> _events.emit(Event.OnError(result.message))
                                                                                     }
                                                                         }
                              }
    }


    fun undoRemoveFilm(film: Film)
    {
        viewModelScope.launch {
                                 filmsRepository.insertFilm(film)
                                                .collect { result -> when(result)
                                                                     {
                                                                        is Result.Ok    -> {}
                                                                        is Result.Error -> _events.emit(Event.OnError(result.message))
                                                                     }
                                                         }
                              }
    }

    private fun createFilmItem(film: Film) :  Item.FilmItem
    {
        return Item.FilmItem(film, { onEditFilm(film) }, { removeFilm(film) } )
    }

    companion object
    {
        val factory : ViewModelProvider.Factory = object : ViewModelProvider.Factory
        {
            override fun <T : ViewModel> create(modelClass: Class<T>, extras: CreationExtras): T
            {
                val application = extras[ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as FilmsApplication
                val savedStateHandle = extras.createSavedStateHandle()
                return MainViewModel(application.repository, savedStateHandle) as T
            }
        }
    }
}

sealed interface Item
{
    class FilmItem(val film: Film, val onEdit : () -> Unit, val onRemove : () -> Unit) : Item
    {
        fun edit()   { onEdit.invoke() }
        fun remove() { onRemove.invoke() }
    }
    class YearItem(val year: Int, val count: Int): Item
}

sealed interface Event
{
    class OnEditFilmRequested(val film: Film): Event
    object OnInsertFilmRequested: Event
    class OnFilmRemoved(val film: Film): Event
    class OnError(val message: String?): Event
}