package es.upsa.mimo.filmstmdb

import android.app.Dialog
import android.content.Context
import android.content.DialogInterface
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import es.upsa.mimo.filmstmdb.databinding.AlertDialogUrlBinding

class PosterDialog: DialogFragment(), DialogInterface.OnClickListener
{
    lateinit var viewBinding: AlertDialogUrlBinding
    lateinit var onPosterWatcherListener : OnPosterWatcherListener

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog
    {
        activity?.let {
                        viewBinding = AlertDialogUrlBinding.inflate( requireActivity().layoutInflater )
                        val builder : AlertDialog.Builder = AlertDialog.Builder( it )
                        return builder.setView( viewBinding.root )
                                      .setTitle( R.string.label_poster_url )
                                      .setPositiveButton(android.R.string.ok, this)
                                      .setNegativeButton(android.R.string.cancel, this)
                                      .create();
                      } ?: throw java.lang.IllegalStateException("Activity no puede ser null")
    }

    override fun onAttach(context: Context)
    {
        super.onAttach(context)
        onPosterWatcherListener = context as OnPosterWatcherListener
    }

    override fun onClick(dialog: DialogInterface?, which: Int)
    {
        when(which)
        {
            DialogInterface.BUTTON_POSITIVE -> onPosterWatcherListener.onCartelChanged( viewBinding.etPoster.text.toString() )
            DialogInterface.BUTTON_NEGATIVE -> dismiss()
        }
    }

    public interface OnPosterWatcherListener
    {
        fun onCartelChanged(text: String)
    }
}